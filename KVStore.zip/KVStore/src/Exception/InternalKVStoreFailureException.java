package Exception;

public class InternalKVStoreFailureException extends Exception{

}
