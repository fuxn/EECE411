package Exception;

public class OutOfSpaceException extends Exception{

}
