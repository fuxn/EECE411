package Exception;

public class UnrecognizedCommandException extends Exception{

}
