package Exception;

public class SystemOverloadException extends Exception{

}
