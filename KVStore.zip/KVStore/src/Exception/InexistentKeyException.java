package Exception;

public class InexistentKeyException extends Exception{
      
}
